from src.motor import Motor

def test_stop():
 m=Motor();m.stop();assert m.speed==0
