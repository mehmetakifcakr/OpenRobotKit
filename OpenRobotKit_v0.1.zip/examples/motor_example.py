from src.motor import Motor
m=Motor();m.set_speed(100)
