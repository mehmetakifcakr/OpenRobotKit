# OpenRobotKit

Open-source robotics toolkit for Arduino, ESP32 and Python.

## Features
- Motor control
- PID controller
- Sensor utilities
- Serial communication
- Examples
