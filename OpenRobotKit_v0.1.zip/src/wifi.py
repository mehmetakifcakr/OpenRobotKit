class WiFi: pass
