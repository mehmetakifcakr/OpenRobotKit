class PID:
    def __init__(self,kp=1,ki=0,kd=0):
        self.kp,self.ki,self.kd=kp,ki,kd
