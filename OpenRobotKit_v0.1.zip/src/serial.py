class SerialConnection: pass
