class Motor:
    def __init__(self): self.speed=0
    def set_speed(self,s): self.speed=s
    def stop(self): self.speed=0
