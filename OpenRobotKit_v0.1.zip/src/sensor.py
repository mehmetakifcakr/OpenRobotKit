class Sensor: pass
